plugins {
    id("com.android.application")
}

android {
    namespace = "com.cassandra.gpsspeedometer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.cassandra.gpsspeedometer"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
