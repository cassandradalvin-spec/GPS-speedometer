package com.cassandra.gpsspeedometer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class SpeedometerView extends View {
    private static final float MAX_GAUGE_SPEED = 30f;
    private static final float START_ANGLE = 135f;
    private static final float SWEEP_ANGLE = 270f;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path needlePath = new Path();
    private float speedKmh = 0f;

    public SpeedometerView(Context context) {
        super(context);
    }

    public SpeedometerView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SpeedometerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setSpeed(float speedKmh) {
        this.speedKmh = Math.max(0f, speedKmh);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float width = getWidth();
        float height = getHeight();
        float size = Math.min(width, height);
        float cx = width / 2f;
        float cy = height / 2f;
        float radius = size * 0.43f;

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(size * 0.018f);
        paint.setColor(Color.rgb(95, 95, 95));
        RectF arc = new RectF(cx - radius, cy - radius, cx + radius, cy + radius);
        canvas.drawArc(arc, START_ANGLE, SWEEP_ANGLE, false, paint);

        // Major and minor tick marks.
        for (int i = 0; i <= 30; i++) {
            float angle = START_ANGLE + (i / MAX_GAUGE_SPEED) * SWEEP_ANGLE;
            double radians = Math.toRadians(angle);
            boolean major = i % 5 == 0;
            float outer = radius;
            float inner = radius - (major ? size * 0.065f : size * 0.035f);
            float x1 = cx + (float) Math.cos(radians) * inner;
            float y1 = cy + (float) Math.sin(radians) * inner;
            float x2 = cx + (float) Math.cos(radians) * outer;
            float y2 = cy + (float) Math.sin(radians) * outer;

            paint.setStrokeWidth(major ? size * 0.012f : size * 0.006f);
            paint.setColor(major ? Color.WHITE : Color.rgb(125, 125, 125));
            canvas.drawLine(x1, y1, x2, y2, paint);

            if (major) {
                float labelRadius = radius - size * 0.105f;
                float lx = cx + (float) Math.cos(radians) * labelRadius;
                float ly = cy + (float) Math.sin(radians) * labelRadius;
                paint.setStyle(Paint.Style.FILL);
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(size * 0.045f);
                paint.setColor(Color.rgb(190, 190, 190));
                Paint.FontMetrics fm = paint.getFontMetrics();
                canvas.drawText(String.valueOf(i), lx, ly - (fm.ascent + fm.descent) / 2f, paint);
                paint.setStyle(Paint.Style.STROKE);
            }
        }

        // Needle. Speeds above the scale pin at the end while the digital readout stays exact.
        float clampedSpeed = Math.min(speedKmh, MAX_GAUGE_SPEED);
        float needleAngle = START_ANGLE + (clampedSpeed / MAX_GAUGE_SPEED) * SWEEP_ANGLE;
        double needleRadians = Math.toRadians(needleAngle);
        float needleLength = radius * 0.69f;
        float tipX = cx + (float) Math.cos(needleRadians) * needleLength;
        float tipY = cy + (float) Math.sin(needleRadians) * needleLength;

        float baseRadius = size * 0.027f;
        float perpendicular = needleAngle + 90f;
        double perpRadians = Math.toRadians(perpendicular);
        float bx1 = cx + (float) Math.cos(perpRadians) * baseRadius;
        float by1 = cy + (float) Math.sin(perpRadians) * baseRadius;
        float bx2 = cx - (float) Math.cos(perpRadians) * baseRadius;
        float by2 = cy - (float) Math.sin(perpRadians) * baseRadius;

        needlePath.reset();
        needlePath.moveTo(tipX, tipY);
        needlePath.lineTo(bx1, by1);
        needlePath.lineTo(bx2, by2);
        needlePath.close();

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(255, 72, 72));
        canvas.drawPath(needlePath, paint);
        canvas.drawCircle(cx, cy, size * 0.035f, paint);

        paint.setColor(Color.WHITE);
        canvas.drawCircle(cx, cy, size * 0.014f, paint);
    }
}
