package com.cassandra.gpsspeedometer;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity implements LocationListener {
    private static final int LOCATION_PERMISSION_REQUEST = 1001;
    private static final String PREFS_NAME = "speedometer_prefs";
    private static final String KEY_MAX_SPEED = "max_speed_kmh";

    private TextView speedText;
    private TextView statusText;
    private TextView maxSpeedText;
    private SpeedometerView speedometerView;
    private LocationManager locationManager;
    private SharedPreferences preferences;
    private float maxSpeedKmh = 0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        speedText = findViewById(R.id.speedText);
        statusText = findViewById(R.id.statusText);
        maxSpeedText = findViewById(R.id.maxSpeedText);
        speedometerView = findViewById(R.id.speedometerView);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        maxSpeedKmh = preferences.getFloat(KEY_MAX_SPEED, 0f);
        updateMaxSpeedDisplay();

        findViewById(R.id.closeButton).setOnClickListener(v -> finishAndRemoveTask());
        findViewById(R.id.resetButton).setOnClickListener(v -> {
            maxSpeedKmh = 0f;
            preferences.edit().putFloat(KEY_MAX_SPEED, 0f).apply();
            updateMaxSpeedDisplay();
        });

        enterImmersiveMode();
        requestGps();
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private void requestGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST
            );
            return;
        }

        startGpsUpdates();
    }

    private void startGpsUpdates() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) return;

        boolean gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if (!gpsEnabled) {
            statusText.setText("Turn GPS on");
            return;
        }

        statusText.setText("Waiting for GPS…");
        locationManager.removeUpdates(this);
        locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                500,
                0,
                this
        );
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location.hasSpeed()) {
            float kmh = location.getSpeed() * 3.6f;
            if (kmh < 0.8f) kmh = 0f;

            speedText.setText(String.format(Locale.getDefault(), "%.0f", kmh));
            speedometerView.setSpeed(kmh);

            // Reject poor-accuracy fixes from setting a bogus permanent maximum.
            boolean reliableEnoughForMax = !location.hasAccuracy() || location.getAccuracy() <= 30f;
            if (reliableEnoughForMax && kmh > maxSpeedKmh) {
                maxSpeedKmh = kmh;
                preferences.edit().putFloat(KEY_MAX_SPEED, maxSpeedKmh).apply();
                updateMaxSpeedDisplay();
            }

            if (location.hasAccuracy()) {
                statusText.setText("GPS accuracy ±" + Math.round(location.getAccuracy()) + " m");
            } else {
                statusText.setText("GPS speed active");
            }
        } else {
            speedText.setText("0");
            speedometerView.setSpeed(0f);
            statusText.setText("Waiting for speed…");
        }
    }

    private void updateMaxSpeedDisplay() {
        maxSpeedText.setText(String.format(Locale.getDefault(), "%.1f", maxSpeedKmh));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startGpsUpdates();
        } else {
            statusText.setText("Location permission required");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        enterImmersiveMode();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            startGpsUpdates();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            locationManager.removeUpdates(this);
        }
    }
}
