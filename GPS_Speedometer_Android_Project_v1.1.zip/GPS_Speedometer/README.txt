GPS Speedometer 1.1
===================

A simple Android GPS speedometer designed for an easy-to-read full-screen display.

Features:
- Large digital speed in km/h
- Analog 0–30 km/h gauge surrounding the digital speed
- Moving red needle
- Maximum speed display (saved until reset)
- RESET button for maximum speed
- X button to close the app
- GPS accuracy display
- Full-screen black display
- GPS-only, no internet required
- No ads, accounts, or analytics
- Keeps the screen awake while open
- Uses Android's built-in LocationManager, not Google Play Services

Maximum-speed protection:
- GPS fixes worse than ±30 m accuracy do not update the saved maximum, reducing false max-speed spikes.

To build:
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Build > Build APK(s).
4. The APK will be in app/build/outputs/apk/debug/app-debug.apk.
