GPS Speedometer
===============

A tiny Android GPS speedometer that displays speed in km/h.

Features:
- Full-screen black display
- Large white speed number
- km/h only
- GPS-only, no internet required
- No ads
- No accounts
- No analytics
- Keeps screen awake while open
- Uses Android's built-in LocationManager, not Google Play Services

To build:
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Build > Build APK(s).
4. The APK will be in app/build/outputs/apk/debug/app-debug.apk.
